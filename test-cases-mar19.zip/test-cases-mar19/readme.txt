Filenames

(d) uses the .data segment
(s) uses the stack
(n) naive allocation
(b) block allocation
(g) graph allocation

sort-dn.s uses a naive allocation on the .data segment

